// dikerjakan oleh: distania_9

exports.up = (pgm) => {
  pgm.createTable('authentications', {
    token: {
      type: 'TEXT',
      notNull: true,
      primaryKey: true,
    },
  });
};

exports.down = (pgm) => {
  pgm.dropTable('authentications');
};
